
public class InsertVehicle {

}
