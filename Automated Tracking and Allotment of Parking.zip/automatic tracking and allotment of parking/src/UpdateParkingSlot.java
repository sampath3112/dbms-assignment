
public class UpdateParkingSlot {

}
