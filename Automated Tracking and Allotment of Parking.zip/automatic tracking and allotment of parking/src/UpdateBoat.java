import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateBoat extends Panel 
{
	Button updateBoatButton;
	List boatIDList;
	TextField bidText, bnameText, colorText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateBoat() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","anoop","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadBoats() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM boats");
		  while (rs.next()) 
		  {
			boatIDList.add(rs.getString("BID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    boatIDList = new List(6);
		loadBoats();
		add(boatIDList);
		
		//When a list item is selected populate the text fields
		boatIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM boats");
					while (rs.next()) 
					{
						if (rs.getString("BID").equals(boatIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						bidText.setText(rs.getString("BID"));
						bnameText.setText(rs.getString("BNAME"));
						colorText.setText(rs.getString("COLOR"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateBoatButton = new Button("Update Boat");
		updateBoatButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE boats "
					+ "SET bname='" + bnameText.getText() + "', "
					+ "color='" + colorText.getText() + "' WHERE bid = "
					+ boatIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					boatIDList.removeAll();
					loadBoats();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		bidText = new TextField(15);
		bidText.setEditable(false);
		bnameText = new TextField(15);
		colorText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Boat ID:"));
		first.add(bidText);
		first.add(new Label("Name:"));
		first.add(bnameText);
		first.add(new Label("color:"));
		first.add(colorText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateBoatButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateBoat upb = new UpdateBoat();
		
		upb.buildGUI();
	}
}
