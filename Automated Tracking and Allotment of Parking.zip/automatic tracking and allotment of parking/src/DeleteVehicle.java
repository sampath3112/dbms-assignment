
public class DeleteVehicle {

}
