
public class UpdateDuration {

}
