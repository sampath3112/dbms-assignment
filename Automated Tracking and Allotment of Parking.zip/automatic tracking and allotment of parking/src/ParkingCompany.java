import java.awt.*; 
import java.awt.event.*; 

class ParkingCompany extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  InsertCustomer sail;
	  UpdateCustomer ups;
	  DeleteCustomer dels;
	  UpdateBoat upb;
	  MakeReservation mks;
	  Panel home,welcome; 
	  
	  ParkingCompany() 
	  { 
			cardLO = new CardLayout(); 
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setText("Welcome to parking Company");
			
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);		 
			
			//create panels for each of our menu items and build them with respective components
			sail = new InsertCustomer(); sail.buildGUI();
			ups = new UpdateCustomer();  ups.buildGUI();
			dels = new DeleteCustomer();	dels.buildGUI();
			upb = new UpdateBoat();		upb.buildGUI();
			mks= new MakeReservation();	mks.buildGUI();

			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(sail, "InsertCustomer"); 
			home.add(ups, "UpdateCustomer"); 
			home.add(dels, "DeleteCustomer"); 
			home.add(upb, "UpdateBoat"); 
			home.add(mks, "MakeReserve"); 
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu sailor = new Menu("Customer"); 
			MenuItem item1, item2, item3; 
			sailor.add(item1 = new MenuItem("Insert Customer")); 
			sailor.add(item2 = new MenuItem("View Customers")); 
			sailor.add(item3 = new MenuItem("Delete Customer")); 
			mbar.add(sailor);  
		 
			Menu boat = new Menu("Users"); 
			MenuItem item4, item5, item6; 
			boat.add(item4 = new MenuItem("Insert User")); 
			boat.add(item5 = new MenuItem("View user")); 
			boat.add(item6 = new MenuItem("Delete Boat"));  
			mbar.add(boat); 
			
			Menu reserve = new Menu("ParkingSlots"); 
			MenuItem item7, item8, item9; 
			reserve.add(item7 = new MenuItem("Make Reservation")); 
			reserve.add(item8 = new MenuItem("View Reservation")); 
			reserve.add(item9 = new MenuItem("Delete Reservation")); 
			mbar.add(reserve);
			
			Menu vehicle = new Menu("Vehicle"); 
			MenuItem item10, item11, item12; 
			vehicle.add(item10 = new MenuItem("Insert Vehicle")); 
			vehicle.add(item11 = new MenuItem("Update Vehicles")); 
			vehicle.add(item12 = new MenuItem("Delete Vehicle")); 
			mbar.add(vehicle);
			
			Menu duration = new Menu("Duration"); 
			MenuItem item13, item14, item15; 
			duration.add(item13 = new MenuItem("Insert")); 
			duration.add(item14 = new MenuItem("Update")); 
			duration.add(item15 = new MenuItem("Delete")); 
			mbar.add(duration);
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this);
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Parking Company"); 
			Color clr = new Color(0,255,255);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Customer"))
		  {
			cardLO.show(home, "InsertCustomer"); 			
          }			
		 
		 else if(arg.equals("View Customers")) 
		 {
			cardLO.show(home, "UpdateCustomer"); 			
		 }
		 
		 else if(arg.equals("Delete Customer")) 
		 {
			cardLO.show(home, "DeleteCustomer"); 			
		 }
		 
		 else if(arg.equals("Insert User")) 
		 {
			cardLO.show(home, "InsertUser"); 				
		 }
		 else if(arg.equals("Make Reservation")) 
		 {
			cardLO.show(home, "MakeReserve"); 				
		 }			 
	  }
	  public static void main(String ... args)
	  {
			new ParkingCompany();	  
	  }
} 
 

 
