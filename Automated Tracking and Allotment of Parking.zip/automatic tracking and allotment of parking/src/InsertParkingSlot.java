
public class InsertParkingSlot {

}
