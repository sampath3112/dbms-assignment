import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertCustomer extends Panel 
{
	Button insertCustomerButton;
	TextField cidText, cnameText, cmobileText, cpassText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertCustomer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737099","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertCustomerButton = new Button("Submit");
		insertCustomerButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO customer VALUES(" + cidText.getText() + ", " + "'" + cnameText.getText() + "'," + cmobileText.getText() + ",'" + cpassText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		cidText = new TextField(15);
		cnameText = new TextField(15);
		cmobileText = new TextField(15);
		cpassText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("customer ID:"));
		first.add(cidText);
		first.add(new Label("customer Name:"));
		first.add(cnameText);
		first.add(new Label("mobile number"));
		first.add(cmobileText);
		first.add(new Label("cpass"));
		first.add(cpassText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertCustomerButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args)
	{
		InsertCustomer sail = new InsertCustomer();
			
		sail.buildGUI();
	}
}
