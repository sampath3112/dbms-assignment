
public class DeleteParkingSlot {

}
