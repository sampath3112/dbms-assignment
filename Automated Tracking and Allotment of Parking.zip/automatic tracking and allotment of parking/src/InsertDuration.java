
public class InsertDuration {

}
