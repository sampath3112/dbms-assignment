
public class UpdateVehicle {

}
