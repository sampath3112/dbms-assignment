import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCustomer extends Panel
{
	Button updateCustomerButton;
	List customerIDList;
	TextField cidText, cnameText, cmobileText, cpassText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCustomer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737099","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCustomer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT CID FROM customer");
		  while (rs.next()) 
		  {
			customerIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    customerIDList = new List(10);
		loadCustomer();
		add(customerIDList);
		
		//When a list item is selected populate the text fields
		customerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer where CID ="+customerIDList.getSelectedItem());
					rs.next();
					cidText.setText(rs.getString("CID"));
					cnameText.setText(rs.getString("CNAME"));
					cmobileText.setText(rs.getString("mobile"));
					cpassText.setText(rs.getString("cpass"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateCustomerButton = new Button("Modify");
		updateCustomerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE customer "
					+ "SET cname='" + cnameText.getText() + "', "
					+ "cmobile=" + cmobileText.getText() + ", "
					+ "cpass ='"+ cpassText.getText() + "' WHERE cid = "
					+ customerIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					customerIDList.removeAll();
					loadCustomer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		cnameText = new TextField(15);
		cmobileText = new TextField(15);
		cpassText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("customer ID:"));
		first.add(cidText);
		first.add(new Label("Customer Name:"));
		first.add(cnameText);
		first.add(new Label("mobile number"));
		first.add(cmobileText);
		first.add(new Label("cpass"));
		first.add(cpassText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateCustomerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateCustomer ups = new UpdateCustomer();
		ups.buildGUI();
	}
}
