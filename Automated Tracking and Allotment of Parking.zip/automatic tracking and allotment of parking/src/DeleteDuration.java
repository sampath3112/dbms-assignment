
public class DeleteDuration {

}
