import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class MakeReservation extends Panel 
{
	Button reserveButton;
	TextField dateText;
	Choice sidSelect, bidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public MakeReservation() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","anoop","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSailors() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM sailors");
		  while (rs.next()) 
		  {
			sidSelect.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadBoats() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM boats");
		  while (rs.next()) 
		  {
			bidSelect.add(rs.getString("BID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    sidSelect = new Choice();
		loadSailors();
		
		bidSelect = new Choice();
		loadBoats();
		
	    
		//Handle Reserve Button
		reserveButton = new Button("Reserve");
		reserveButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO reserves VALUES(" + sidSelect.getSelectedItem() + ", " + bidSelect.getSelectedItem() + ",'" + dateText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		dateText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Sailor ID:"));
		first.add(sidSelect);
		first.add(new Label("Boat ID:"));
		first.add(bidSelect);
		first.add(new Label("Date:"));
		first.add(dateText);

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(reserveButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		MakeReservation mks = new MakeReservation();

		mks.buildGUI();
	}
}
